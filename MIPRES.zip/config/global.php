<?php
////////////////////////////////////////////////////////////////////////////////
/////////////////////////       SISTEMA GRAFICAS       /////////////////////////
/////////////////////////      PIJAOS SALUD EPSI      //////////////////////////
/////////////////////////    CONSTANTES DE CONEXION   //////////////////////////
/////////////////////////  DEPARTAMENTO DE DESARROLLO  /////////////////////////
///////           PARAMETROS DE CONEXION A LA BASE DE DATOS           //////////
////////////////////////////////////////////////////////////////////////////////


//ip de la pc del servidor de base de datos
//define("DB_HOST", "192.168.20.117");
define("DB_HOST", "192.168.20.250");

//nombre de la base de datos
define("DB_NAME", "gemaeps");

//usuario de la base de datos
//define("DB_USERNAME", "sa");
define("DB_USERNAME", "LCORTES");

//contraseña del usuario de la base de datos
//define("DB_PASSWORD", "Colombia01+");
define("DB_PASSWORD", "pra0271LCORTES");

//definimos la codificacion de los caracteres
define("DB_ENCODE", "UTF-8");

